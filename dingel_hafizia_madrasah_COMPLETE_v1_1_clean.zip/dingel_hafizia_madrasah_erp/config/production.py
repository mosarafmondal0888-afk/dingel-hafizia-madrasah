import os


def apply_production_settings(settings):
    settings.DEBUG = os.getenv("DJANGO_DEBUG", "False").lower() == "true"
    settings.SECRET_KEY = os.getenv(
        "DJANGO_SECRET_KEY",
        settings.SECRET_KEY,
    )
    hosts = os.getenv("DJANGO_ALLOWED_HOSTS", "localhost,127.0.0.1")
    settings.ALLOWED_HOSTS = [
        item.strip() for item in hosts.split(",") if item.strip()
    ]

    csrf_origins = os.getenv("DJANGO_CSRF_TRUSTED_ORIGINS", "")
    settings.CSRF_TRUSTED_ORIGINS = [
        item.strip() for item in csrf_origins.split(",") if item.strip()
    ]

    if not settings.DEBUG:
        settings.SECURE_SSL_REDIRECT = True
        settings.SESSION_COOKIE_SECURE = True
        settings.CSRF_COOKIE_SECURE = True
        settings.SECURE_HSTS_SECONDS = 31536000
        settings.SECURE_HSTS_INCLUDE_SUBDOMAINS = True
        settings.SECURE_HSTS_PRELOAD = True
