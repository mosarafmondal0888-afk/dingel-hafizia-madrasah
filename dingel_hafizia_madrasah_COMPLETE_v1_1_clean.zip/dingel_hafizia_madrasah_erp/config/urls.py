from django.contrib import admin
from django.conf import settings
from django.conf.urls.static import static
from django.urls import include, path
from django.views.i18n import set_language

from core.views import dashboard

urlpatterns = [
    path("admin/", admin.site.urls),
    path("login/", include("accounts.urls")),
    path("", dashboard, name="dashboard"),
    path("i18n/setlang/", set_language, name="set_language"),
    path("students/", include("students.urls")),
    path("finance/", include("finance.urls")),
    path("reports/", include("reports.urls")),
]

urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
