# v0.9 — Reports & Export

Added:
- Financial reporting dashboard
- Custom date-range filtering
- Income summary
- Expense summary
- Salary summary
- Restricted fund distribution summary
- Net calculation
- PDF financial report
- Excel financial report
- Professional report UI
- English + বাংলা labels

PDF note:
The first PDF implementation uses standard ReportLab fonts. A future release should embed a Bengali Unicode font for fully bilingual PDF output.
