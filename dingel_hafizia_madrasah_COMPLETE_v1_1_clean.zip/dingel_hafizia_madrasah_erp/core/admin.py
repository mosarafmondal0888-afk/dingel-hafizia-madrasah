from django.contrib import admin

from .models import IndianState


@admin.register(IndianState)
class IndianStateAdmin(admin.ModelAdmin):
    list_display = ("name", "code")
    search_fields = ("name", "code")
