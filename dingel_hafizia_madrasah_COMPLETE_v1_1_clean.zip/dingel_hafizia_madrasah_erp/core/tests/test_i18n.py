from django.test import TestCase
from django.urls import reverse


class LanguageSwitchTest(TestCase):
    def test_dashboard_is_available(self):
        response = self.client.get(reverse("dashboard"))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Dashboard")
