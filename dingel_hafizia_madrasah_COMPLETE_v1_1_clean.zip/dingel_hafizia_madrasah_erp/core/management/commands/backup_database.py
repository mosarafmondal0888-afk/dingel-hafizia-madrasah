from datetime import datetime
from pathlib import Path
from django.conf import settings
from django.core import management
from django.core.management.base import BaseCommand


class Command(BaseCommand):
    help = "Create a JSON database backup."

    def add_arguments(self, parser):
        parser.add_argument("--output", default="backups")

    def handle(self, *args, **options):
        output_dir = Path(options["output"])
        output_dir.mkdir(parents=True, exist_ok=True)
        filename = (
            output_dir
            / f"madrasah-backup-{datetime.now():%Y%m%d-%H%M%S}.json"
        )
        with filename.open("w", encoding="utf-8") as handle:
            management.call_command(
                "dumpdata",
                "--natural-foreign",
                "--natural-primary",
                stdout=handle,
            )
        self.stdout.write(self.style.SUCCESS(f"Backup created: {filename}"))
