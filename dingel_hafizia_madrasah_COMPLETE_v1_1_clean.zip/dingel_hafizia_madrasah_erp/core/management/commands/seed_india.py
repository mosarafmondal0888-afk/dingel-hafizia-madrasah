from django.core.management.base import BaseCommand

from core.models import IndianState


INDIA_STATES = [
    ("Andaman and Nicobar Islands", "AN"),
    ("Andhra Pradesh", "AP"),
    ("Arunachal Pradesh", "AR"),
    ("Assam", "AS"),
    ("Bihar", "BR"),
    ("Chandigarh", "CH"),
    ("Chhattisgarh", "CG"),
    ("Dadra and Nagar Haveli and Daman and Diu", "DH"),
    ("Delhi", "DL"),
    ("Goa", "GA"),
    ("Gujarat", "GJ"),
    ("Haryana", "HR"),
    ("Himachal Pradesh", "HP"),
    ("Jammu and Kashmir", "JK"),
    ("Jharkhand", "JH"),
    ("Karnataka", "KA"),
    ("Kerala", "KL"),
    ("Ladakh", "LA"),
    ("Lakshadweep", "LD"),
    ("Madhya Pradesh", "MP"),
    ("Maharashtra", "MH"),
    ("Manipur", "MN"),
    ("Meghalaya", "ML"),
    ("Mizoram", "MZ"),
    ("Nagaland", "NL"),
    ("Odisha", "OD"),
    ("Puducherry", "PY"),
    ("Punjab", "PB"),
    ("Rajasthan", "RJ"),
    ("Sikkim", "SK"),
    ("Tamil Nadu", "TN"),
    ("Telangana", "TS"),
    ("Tripura", "TR"),
    ("Uttar Pradesh", "UP"),
    ("Uttarakhand", "UK"),
    ("West Bengal", "WB"),
]


class Command(BaseCommand):
    help = "Seed Indian states and union territories."

    def handle(self, *args, **options):
        for name, code in INDIA_STATES:
            IndianState.objects.update_or_create(
                code=code,
                defaults={"name": name},
            )
        self.stdout.write(
            self.style.SUCCESS("Indian states and union territories seeded.")
        )
