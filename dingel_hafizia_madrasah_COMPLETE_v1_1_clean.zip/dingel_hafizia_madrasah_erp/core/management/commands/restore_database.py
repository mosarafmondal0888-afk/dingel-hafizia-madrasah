from pathlib import Path
from django.core import management
from django.core.management.base import BaseCommand, CommandError


class Command(BaseCommand):
    help = "Restore a JSON database backup."

    def add_arguments(self, parser):
        parser.add_argument("backup")

    def handle(self, *args, **options):
        backup = Path(options["backup"])
        if not backup.is_file():
            raise CommandError(f"Backup not found: {backup}")

        with backup.open("r", encoding="utf-8") as handle:
            management.call_command("loaddata", handle.name)

        self.stdout.write(
            self.style.SUCCESS(f"Database restored from: {backup}")
        )
