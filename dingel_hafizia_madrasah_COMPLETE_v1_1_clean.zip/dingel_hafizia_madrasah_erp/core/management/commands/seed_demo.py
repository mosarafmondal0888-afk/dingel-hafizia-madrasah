from decimal import Decimal
from django.core.management.base import BaseCommand

from finance.models import Account, DonationFund
from students.models import ClassGroup


class Command(BaseCommand):
    help = "Create safe starter master data."

    def handle(self, *args, **options):
        class_names = [
            "Nurani",
            "Nazera",
            "Hifz",
            "Takmil / Revision",
        ]
        for name in class_names:
            ClassGroup.objects.get_or_create(name=name)

        funds = [
            ("GENERAL", "General Donation / দান"),
            ("SADAQAH", "Sadaqah / সদকা"),
            ("ZAKAT", "Zakat / যাকাত"),
            ("FITRAH", "Fitrah / ফিতরা"),
            ("LILLAH", "Lillah / লিল্লাহ"),
            ("WAQF", "Waqf / ওয়াকফ"),
        ]
        for code, name in funds:
            DonationFund.objects.get_or_create(code=code, defaults={"name": name})

        accounts = [
            ("CASH", "Main Cash"),
            ("BANK", "Main Bank"),
        ]
        for code, name in accounts:
            Account.objects.get_or_create(
                code=code,
                defaults={"name": name, "account_type": "ASSET"},
            )

        self.stdout.write(self.style.SUCCESS("Demo master data created."))
