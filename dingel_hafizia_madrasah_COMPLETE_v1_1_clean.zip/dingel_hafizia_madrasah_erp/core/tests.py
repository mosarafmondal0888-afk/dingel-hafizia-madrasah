from django.test import SimpleTestCase
from django.urls import reverse


class CoreSmokeTests(SimpleTestCase):
    def test_login_route_exists(self):
        response = self.client.get(reverse("login"))
        self.assertEqual(response.status_code, 200)

    def test_language_switch_endpoint_exists(self):
        response = self.client.post(
            reverse("set_language"),
            {"language": "bn", "next": "/"},
        )
        self.assertIn(response.status_code, {302, 303})
