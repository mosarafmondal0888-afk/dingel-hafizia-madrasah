from decimal import Decimal

from django.contrib.auth.decorators import login_required
from django.db.models import Sum
from django.shortcuts import render

from finance.models import Account, Donation, Expense, FeePayment
from students.models import Student


@login_required
def dashboard(request):
    context = {
        "student_count": Student.objects.filter(is_active=True).count(),
        "fee_total": FeePayment.objects.aggregate(
            total=Sum("amount")
        )["total"] or Decimal("0.00"),
        "donation_total": Donation.objects.aggregate(
            total=Sum("amount")
        )["total"] or Decimal("0.00"),
        "expense_total": Expense.objects.aggregate(
            total=Sum("amount")
        )["total"] or Decimal("0.00"),
        "accounts": Account.objects.filter(is_active=True),
    }
    return render(request, "dashboard.html", context)
