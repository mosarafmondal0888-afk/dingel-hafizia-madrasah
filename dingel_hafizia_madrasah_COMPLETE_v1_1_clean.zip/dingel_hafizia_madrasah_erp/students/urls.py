from django.urls import path

from .views import student_create, student_detail, student_list

urlpatterns = [
    path("", student_list, name="student-list"),
    path("new/", student_create, name="student-create"),
    path("<int:pk>/", student_detail, name="student-detail"),
]
