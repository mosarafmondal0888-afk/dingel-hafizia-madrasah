from django.contrib import admin

from .models import Attendance, ClassGroup, Guardian, HifzProgress, Student


@admin.register(Student)
class StudentAdmin(admin.ModelAdmin):
    list_display = (
        "admission_no",
        "full_name",
        "class_group",
        "guardian",
        "status",
        "is_boarder",
    )
    list_filter = ("status", "class_group", "is_boarder")
    search_fields = ("admission_no", "full_name", "name_bn", "phone")


@admin.register(Guardian)
class GuardianAdmin(admin.ModelAdmin):
    search_fields = ("name", "phone")


@admin.register(ClassGroup)
class ClassGroupAdmin(admin.ModelAdmin):
    search_fields = ("name",)


@admin.register(HifzProgress)
class HifzProgressAdmin(admin.ModelAdmin):
    list_display = ("student", "date", "juz_no", "surah", "page_from", "page_to")
    list_filter = ("date",)
    search_fields = ("student__full_name", "student__admission_no", "surah")


@admin.register(Attendance)
class AttendanceAdmin(admin.ModelAdmin):
    list_display = ("student", "date", "status")
    list_filter = ("date", "status")
    search_fields = ("student__full_name", "student__admission_no")
