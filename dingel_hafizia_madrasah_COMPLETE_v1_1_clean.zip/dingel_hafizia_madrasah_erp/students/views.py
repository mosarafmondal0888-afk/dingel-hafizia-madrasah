from django.contrib import messages
from django.shortcuts import get_object_or_404, redirect, render

from .models import ClassGroup, Guardian, HifzProgress, Student


def student_list(request):
    query = request.GET.get("q", "").strip()
    students = Student.objects.select_related("guardian", "class_group")
    if query:
        students = students.filter(
            full_name__icontains=query
        ) | students.filter(
            admission_no__icontains=query
        ) | students.filter(
            phone__icontains=query
        )
    return render(
        request,
        "students/student_list.html",
        {"students": students, "query": query},
    )


def student_create(request):
    classes = ClassGroup.objects.all()
    if request.method == "POST":
        guardian = Guardian.objects.create(
            name=request.POST.get("guardian_name", "").strip(),
            relationship=request.POST.get("guardian_relationship", "").strip(),
            phone=request.POST.get("guardian_phone", "").strip(),
            address=request.POST.get("guardian_address", "").strip(),
        )
        student = Student.objects.create(
            admission_no=request.POST.get("admission_no", "").strip(),
            full_name=request.POST.get("full_name", "").strip(),
            name_bn=request.POST.get("name_bn", "").strip(),
            admission_date=request.POST.get("admission_date"),
            guardian=guardian,
            class_group_id=request.POST.get("class_group"),
            phone=request.POST.get("phone", "").strip(),
            alternate_phone=request.POST.get("alternate_phone", "").strip(),
            email=request.POST.get("email", "").strip(),
            aadhaar_last4=request.POST.get("aadhaar_last4", "").strip(),
            address=request.POST.get("address", "").strip(),
            village=request.POST.get("village", "").strip(),
            post_office=request.POST.get("post_office", "").strip(),
            police_station=request.POST.get("police_station", "").strip(),
            district=request.POST.get("district", "").strip(),
            state=request.POST.get("state", "West Bengal").strip(),
            pin_code=request.POST.get("pin_code", "").strip(),
            blood_group=request.POST.get("blood_group", "").strip(),
            previous_madrasa=request.POST.get("previous_madrasa", "").strip(),
            is_boarder=request.POST.get("is_boarder") == "on",
            notes=request.POST.get("notes", "").strip(),
        )
        messages.success(request, "Student admission created successfully.")
        return redirect("student-detail", pk=student.pk)

    return render(request, "students/student_form.html", {"classes": classes})


def student_detail(request, pk):
    student = get_object_or_404(
        Student.objects.select_related("guardian", "class_group"),
        pk=pk,
    )
    progress = student.hifz_progress.all()[:20]
    payments = student.fee_payments.select_related("invoice").all()[:20]
    invoices = student.fee_invoices.all()[:20]
    return render(
        request,
        "students/student_detail.html",
        {
            "student": student,
            "progress": progress,
            "payments": payments,
            "invoices": invoices,
        },
    )
