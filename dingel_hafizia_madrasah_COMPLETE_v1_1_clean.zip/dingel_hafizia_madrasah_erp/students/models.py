from django.db import models


class ClassGroup(models.Model):
    name = models.CharField(max_length=120, unique=True)
    description = models.TextField(blank=True)

    class Meta:
        ordering = ["name"]

    def __str__(self):
        return self.name


class Guardian(models.Model):
    name = models.CharField(max_length=150)
    relationship = models.CharField(max_length=80, blank=True)
    phone = models.CharField(max_length=30, blank=True)
    alternate_phone = models.CharField(max_length=30, blank=True)
    email = models.EmailField(blank=True)
    aadhaar_last4 = models.CharField(max_length=4, blank=True)
    address = models.TextField(blank=True)
    village = models.CharField(max_length=120, blank=True)
    post_office = models.CharField(max_length=120, blank=True)
    police_station = models.CharField(max_length=120, blank=True)
    district = models.CharField(max_length=120, blank=True)
    state = models.CharField(max_length=120, blank=True, default="West Bengal")
    pin_code = models.CharField(max_length=6, blank=True)
    blood_group = models.CharField(max_length=5, blank=True)
    previous_madrasa = models.CharField(max_length=180, blank=True)

    def __str__(self):
        return self.name


class Student(models.Model):
    class Status(models.TextChoices):
        ACTIVE = "ACTIVE", "Active"
        INACTIVE = "INACTIVE", "Inactive"
        GRADUATED = "GRADUATED", "Graduated"
        TRANSFERRED = "TRANSFERRED", "Transferred"

    admission_no = models.CharField(max_length=40, unique=True)
    full_name = models.CharField(max_length=180)
    name_bn = models.CharField(max_length=180, blank=True)
    date_of_birth = models.DateField(null=True, blank=True)
    admission_date = models.DateField()
    guardian = models.ForeignKey(
        Guardian,
        on_delete=models.PROTECT,
        related_name="students",
    )
    class_group = models.ForeignKey(
        ClassGroup,
        on_delete=models.PROTECT,
        related_name="students",
    )
    phone = models.CharField(max_length=30, blank=True)
    alternate_phone = models.CharField(max_length=30, blank=True)
    email = models.EmailField(blank=True)
    aadhaar_last4 = models.CharField(max_length=4, blank=True)
    address = models.TextField(blank=True)
    village = models.CharField(max_length=120, blank=True)
    post_office = models.CharField(max_length=120, blank=True)
    police_station = models.CharField(max_length=120, blank=True)
    district = models.CharField(max_length=120, blank=True)
    state = models.CharField(max_length=120, blank=True, default="West Bengal")
    pin_code = models.CharField(max_length=6, blank=True)
    blood_group = models.CharField(max_length=5, blank=True)
    previous_madrasa = models.CharField(max_length=180, blank=True)
    status = models.CharField(
        max_length=20,
        choices=Status.choices,
        default=Status.ACTIVE,
    )
    is_boarder = models.BooleanField(default=False)
    photo = models.ImageField(upload_to="students/photos/", blank=True, null=True)
    notes = models.TextField(blank=True)

    class Meta:
        ordering = ["full_name"]

    def __str__(self):
        return f"{self.admission_no} - {self.full_name}"


class HifzProgress(models.Model):
    student = models.ForeignKey(
        Student,
        on_delete=models.CASCADE,
        related_name="hifz_progress",
    )
    date = models.DateField()
    juz_no = models.PositiveSmallIntegerField(null=True, blank=True)
    surah = models.CharField(max_length=120, blank=True)
    page_from = models.PositiveSmallIntegerField(null=True, blank=True)
    page_to = models.PositiveSmallIntegerField(null=True, blank=True)
    sabaq = models.TextField(blank=True)
    sabqi = models.TextField(blank=True)
    manzil = models.TextField(blank=True)
    teacher_remarks = models.TextField(blank=True)

    class Meta:
        ordering = ["-date", "-id"]

    def __str__(self):
        return f"{self.student} - {self.date}"


class Attendance(models.Model):
    class Status(models.TextChoices):
        PRESENT = "PRESENT", "Present"
        ABSENT = "ABSENT", "Absent"
        LEAVE = "LEAVE", "Leave"

    student = models.ForeignKey(
        Student,
        on_delete=models.CASCADE,
        related_name="attendance",
    )
    date = models.DateField()
    status = models.CharField(max_length=10, choices=Status.choices)
    remarks = models.CharField(max_length=255, blank=True)

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=["student", "date"],
                name="unique_student_attendance_date",
            )
        ]
