from datetime import date
from decimal import Decimal
from io import BytesIO

from django.db.models import Sum
from django.http import HttpResponse
from django.shortcuts import render

from openpyxl import Workbook
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas

from finance.models import (
    Donation,
    Expense,
    FeePayment,
    FundDistribution,
    Income,
    SalaryPayment,
)


def _date_range(request):
    today = date.today()
    start = request.GET.get("start") or today.replace(day=1).isoformat()
    end = request.GET.get("end") or today.isoformat()
    return start, end


def report_dashboard(request):
    start, end = _date_range(request)

    fees = FeePayment.objects.filter(payment_date__range=(start, end))
    donations = Donation.objects.filter(donation_date__range=(start, end))
    income = Income.objects.filter(income_date__range=(start, end))
    expenses = Expense.objects.filter(expense_date__range=(start, end))
    salaries = SalaryPayment.objects.filter(
        payment_date__range=(start, end),
        status=SalaryPayment.Status.PAID,
    )
    distributions = FundDistribution.objects.filter(
        distribution_date__range=(start, end)
    )

    totals = {
        "fees": fees.aggregate(total=Sum("amount"))["total"] or Decimal("0.00"),
        "donations": donations.aggregate(total=Sum("amount"))["total"] or Decimal("0.00"),
        "income": income.aggregate(total=Sum("amount"))["total"] or Decimal("0.00"),
        "expenses": expenses.aggregate(total=Sum("amount"))["total"] or Decimal("0.00"),
        "salaries": salaries.aggregate(total=Sum("net_amount"))["total"] or Decimal("0.00"),
        "distributions": distributions.aggregate(total=Sum("amount"))["total"] or Decimal("0.00"),
    }
    totals["total_income"] = totals["fees"] + totals["donations"] + totals["income"]
    totals["total_outflow"] = totals["expenses"] + totals["salaries"]
    totals["net"] = totals["total_income"] - totals["total_outflow"]

    return render(
        request,
        "reports/dashboard.html",
        {
            "start": start,
            "end": end,
            "totals": totals,
            "fee_count": fees.count(),
            "donation_count": donations.count(),
            "expense_count": expenses.count(),
        },
    )


def report_excel(request):
    start, end = _date_range(request)
    workbook = Workbook()
    sheet = workbook.active
    sheet.title = "Financial Summary"

    headers = [
        "Report",
        "Amount (INR)",
    ]
    sheet.append(headers)

    rows = [
        ("Fee Collection", FeePayment.objects.filter(
            payment_date__range=(start, end)
        ).aggregate(total=Sum("amount"))["total"] or 0),
        ("Donations", Donation.objects.filter(
            donation_date__range=(start, end)
        ).aggregate(total=Sum("amount"))["total"] or 0),
        ("Other Income", Income.objects.filter(
            income_date__range=(start, end)
        ).aggregate(total=Sum("amount"))["total"] or 0),
        ("Expenses", Expense.objects.filter(
            expense_date__range=(start, end)
        ).aggregate(total=Sum("amount"))["total"] or 0),
        ("Salary", SalaryPayment.objects.filter(
            payment_date__range=(start, end),
            status=SalaryPayment.Status.PAID,
        ).aggregate(total=Sum("net_amount"))["total"] or 0),
        ("Fund Distributions", FundDistribution.objects.filter(
            distribution_date__range=(start, end)
        ).aggregate(total=Sum("amount"))["total"] or 0),
    ]

    for row in rows:
        sheet.append(row)

    sheet.append([])
    sheet.append(["Period", f"{start} to {end}"])
    sheet.column_dimensions["A"].width = 28
    sheet.column_dimensions["B"].width = 20

    output = BytesIO()
    workbook.save(output)
    output.seek(0)

    response = HttpResponse(
        output.read(),
        content_type=(
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        ),
    )
    response["Content-Disposition"] = (
        f'attachment; filename="madrasah-financial-report-{start}-to-{end}.xlsx"'
    )
    return response


def report_pdf(request):
    start, end = _date_range(request)

    fee_total = FeePayment.objects.filter(
        payment_date__range=(start, end)
    ).aggregate(total=Sum("amount"))["total"] or 0
    donation_total = Donation.objects.filter(
        donation_date__range=(start, end)
    ).aggregate(total=Sum("amount"))["total"] or 0
    income_total = Income.objects.filter(
        income_date__range=(start, end)
    ).aggregate(total=Sum("amount"))["total"] or 0
    expense_total = Expense.objects.filter(
        expense_date__range=(start, end)
    ).aggregate(total=Sum("amount"))["total"] or 0
    salary_total = SalaryPayment.objects.filter(
        payment_date__range=(start, end),
        status=SalaryPayment.Status.PAID,
    ).aggregate(total=Sum("net_amount"))["total"] or 0
    distribution_total = FundDistribution.objects.filter(
        distribution_date__range=(start, end)
    ).aggregate(total=Sum("amount"))["total"] or 0

    total_income = fee_total + donation_total + income_total
    total_outflow = expense_total + salary_total

    response = HttpResponse(content_type="application/pdf")
    response["Content-Disposition"] = (
        f'attachment; filename="madrasah-financial-report-{start}-to-{end}.pdf"'
    )

    pdf = canvas.Canvas(response, pagesize=A4)
    width, height = A4
    pdf.setTitle("Madrasah Financial Report")
    pdf.setFont("Helvetica-Bold", 18)
    pdf.drawCentredString(width / 2, height - 55, "Dingel Hafizia Madrasah")
    pdf.setFont("Helvetica", 10)
    pdf.drawCentredString(
        width / 2,
        height - 75,
        f"Financial Report | {start} to {end} | India | INR",
    )

    y = height - 120
    pdf.setFont("Helvetica-Bold", 12)
    pdf.drawString(60, y, "Income")
    y -= 25
    pdf.setFont("Helvetica", 11)
    for label, amount in [
        ("Fee Collection", fee_total),
        ("Donations", donation_total),
        ("Other Income", income_total),
    ]:
        pdf.drawString(75, y, label)
        pdf.drawRightString(width - 60, y, f"INR {amount}")
        y -= 21

    pdf.setFont("Helvetica-Bold", 12)
    pdf.drawString(60, y, "Outflow")
    y -= 25
    pdf.setFont("Helvetica", 11)
    for label, amount in [
        ("Expenses", expense_total),
        ("Salary", salary_total),
        ("Fund Distributions", distribution_total),
    ]:
        pdf.drawString(75, y, label)
        pdf.drawRightString(width - 60, y, f"INR {amount}")
        y -= 21

    y -= 10
    pdf.line(60, y, width - 60, y)
    y -= 25
    pdf.setFont("Helvetica-Bold", 13)
    pdf.drawString(60, y, "Total Income")
    pdf.drawRightString(width - 60, y, f"INR {total_income}")
    y -= 25
    pdf.drawString(60, y, "Operating Outflow")
    pdf.drawRightString(width - 60, y, f"INR {total_outflow}")
    y -= 25
    pdf.drawString(60, y, "Net")
    pdf.drawRightString(width - 60, y, f"INR {total_income - total_outflow}")

    pdf.setFont("Helvetica", 9)
    pdf.drawString(60, 50, "Generated by Dingel Hafizia Madrasah ERP")
    pdf.save()
    return response
