from django.urls import path

from .views import report_dashboard, report_excel, report_pdf

urlpatterns = [
    path("", report_dashboard, name="report-dashboard"),
    path("excel/", report_excel, name="report-excel"),
    path("pdf/", report_pdf, name="report-pdf"),
]
