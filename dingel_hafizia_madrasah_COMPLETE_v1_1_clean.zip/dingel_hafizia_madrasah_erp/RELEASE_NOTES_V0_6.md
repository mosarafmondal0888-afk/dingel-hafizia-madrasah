# v0.6 — Professional Fee Management

Added:
- Class-wise fee structures
- Monthly invoice generation
- Invoice line items
- Academic year and fee month
- Unpaid / partial / paid invoice status
- Automatic outstanding balance
- Fee payment workflow
- Cash / Bank / UPI / Mobile Banking / Cheque
- Automatic receipt number
- PDF fee receipt
- Finance dashboard with outstanding fees
- Bilingual fee UI foundation

Production hardening still required:
- Database migrations in deployment environment
- Authentication/permissions
- CSRF/rate limiting for public deployments
- Bengali font embedding in PDFs
- Payment gateway integration if online UPI collection is required
