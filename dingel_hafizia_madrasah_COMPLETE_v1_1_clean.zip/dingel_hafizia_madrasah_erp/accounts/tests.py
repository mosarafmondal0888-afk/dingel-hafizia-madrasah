from django.test import TestCase
from django.urls import reverse


class AuthenticationTests(TestCase):
    def test_login_page(self):
        response = self.client.get(reverse("login"))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Madrasah ERP Login")

    def test_dashboard_requires_authentication(self):
        response = self.client.get(reverse("dashboard"))
        self.assertIn(response.status_code, {301, 302})
