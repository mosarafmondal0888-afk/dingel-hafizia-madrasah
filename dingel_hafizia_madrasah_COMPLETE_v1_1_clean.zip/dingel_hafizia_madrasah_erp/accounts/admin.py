from django.contrib import admin

from .models import AuditLog, UserProfile


@admin.register(UserProfile)
class UserProfileAdmin(admin.ModelAdmin):
    list_display = ("user", "role", "phone", "is_active")
    list_filter = ("role", "is_active")
    search_fields = ("user__username", "user__first_name", "user__last_name", "phone")


@admin.register(AuditLog)
class AuditLogAdmin(admin.ModelAdmin):
    list_display = (
        "created_at",
        "user",
        "action",
        "method",
        "path",
        "ip_address",
    )
    list_filter = ("method", "created_at", "action")
    search_fields = ("user__username", "action", "path", "details")
    readonly_fields = (
        "created_at",
        "user",
        "action",
        "method",
        "path",
        "ip_address",
        "object_type",
        "object_id",
        "details",
    )
