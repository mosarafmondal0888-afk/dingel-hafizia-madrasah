from django.urls import resolve

from .models import AuditLog


PUBLIC_PREFIXES = (
    "/login/",
    "/i18n/",
    "/static/",
    "/media/",
)


class AccessAndAuditMiddleware:
    ROLE_PREFIXES = {
        "ACCOUNTANT": ("/finance/", "/reports/"),
        "TEACHER": ("/students/",),
        "COLLECTOR": ("/students/", "/finance/"),
        "VIEWER": ("/reports/",),
    }

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        path = request.path

        if not request.user.is_authenticated and not any(
            path.startswith(prefix) for prefix in PUBLIC_PREFIXES
        ):
            from django.shortcuts import redirect
            return redirect(f"/login/?next={request.get_full_path()}")

        if request.user.is_authenticated:
            profile = getattr(request.user, "profile", None)
            role = (
                "ADMIN"
                if request.user.is_superuser
                else getattr(profile, "role", "VIEWER")
            )

            if path.startswith("/admin/") and role != "ADMIN":
                from django.http import HttpResponseForbidden
                return HttpResponseForbidden(
                    "Administrator access is required."
                )

            if not path.startswith("/admin/") and path not in ("/", "/logout/"):
                allowed = self.ROLE_PREFIXES.get(role)
                if allowed and not any(path.startswith(prefix) for prefix in allowed):
                    if path.startswith("/finance/") and role == "TEACHER":
                        from django.http import HttpResponseForbidden
                        return HttpResponseForbidden(
                            "Your role does not have finance access."
                        )
                    if path.startswith("/students/") and role in {
                        "ACCOUNTANT",
                        "VIEWER",
                    }:
                        from django.http import HttpResponseForbidden
                        return HttpResponseForbidden(
                            "Your role does not have student-management access."
                        )

        response = self.get_response(request)

        if request.user.is_authenticated and request.method in {"POST", "PUT", "PATCH", "DELETE"}:
            try:
                route = resolve(request.path)
                AuditLog.objects.create(
                    user=request.user,
                    action=route.url_name or request.path,
                    method=request.method,
                    path=request.path,
                    ip_address=self._ip(request),
                    details="Request recorded by application audit middleware.",
                )
            except Exception:
                # Audit failures must not take down financial operations.
                pass

        return response

    @staticmethod
    def _ip(request):
        forwarded = request.META.get("HTTP_X_FORWARDED_FOR")
        if forwarded:
            return forwarded.split(",")[0].strip()
        return request.META.get("REMOTE_ADDR")
