from django.contrib.auth.models import Group, Permission
from django.core.management.base import BaseCommand


ROLE_PERMISSIONS = {
    "Accountant": [
        ("finance", "view"),
        ("reports", "view"),
    ],
    "Teacher": [
        ("students", "view"),
    ],
    "Fee Collector": [
        ("students", "view"),
        ("finance", "view"),
    ],
    "Viewer": [
        ("reports", "view"),
    ],
}


class Command(BaseCommand):
    help = "Create standard Django permission groups for the madrasah ERP."

    def handle(self, *args, **options):
        for group_name in ROLE_PERMISSIONS:
            Group.objects.get_or_create(name=group_name)

        self.stdout.write(
            self.style.SUCCESS(
                "Standard role groups created. Assign detailed model permissions in Django Admin."
            )
        )
