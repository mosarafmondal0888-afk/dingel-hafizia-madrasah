# India + বাংলা configuration

This build is configured for an Indian madrasah:

- Country: India
- Time zone: Asia/Kolkata
- Currency: Indian Rupee (₹ / INR)
- Financial year: April through March
- Languages: English and বাংলা
- Payment methods planned: Cash, Bank, UPI, Cheque, Mobile Banking
- Indian states and union territories can be seeded with:
  `python manage.py seed_india`

Aadhaar/PAN fields are intentionally not forced into the first version. They can be added as optional fields when the admission workflow is built.
