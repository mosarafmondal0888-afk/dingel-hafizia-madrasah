# v0.5 — Student + Fees Upgrade

Added:

- Professional student admission form
- India-focused student address/profile fields
- Guardian capture during admission
- Student search
- Student profile page
- Hifz progress overview
- Fee invoice overview
- Recent fee payment overview
- PDF fee receipt endpoint
- INR receipt formatting
- UPI payment method support
- Responsive professional forms and tables

Before production:
- Install dependencies
- Run makemigrations/migrate
- Configure PostgreSQL
- Configure media storage
- Add authentication/permissions
- Add Bengali PDF font and fully localized PDF templates
