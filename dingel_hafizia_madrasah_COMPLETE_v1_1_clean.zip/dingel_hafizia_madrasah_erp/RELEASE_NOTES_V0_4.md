# v0.4 Professional India + বাংলা

## Added
- Professional responsive dashboard UI
- English/বাংলা navigation
- India + INR presentation
- Quick actions for admission, fees, donation and expenses
- India-focused student profile fields
- Optional Aadhaar last-4 field (not full Aadhaar)
- Indian address fields
- UPI payment method
- Professional fund category presentation

## Next
- Full admission form
- Student profile page
- Fee structure and automated invoices
- Payment receipt PDF
- Donation receipt PDF
- Zakat/Sadaqah fund reports
- Expense vouchers
- Staff salary
- Financial reports
- Role-based permissions
- Backup/restore
