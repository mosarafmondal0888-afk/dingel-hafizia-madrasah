# v1.0 — Authentication, Roles & Audit

Added:
- Dedicated secure login screen
- Logout
- User profile roles
- Administrator
- Accountant
- Teacher
- Fee Collector
- Viewer
- Access middleware
- Application audit log
- IP address capture
- Request/action logging for write operations
- Django admin user/profile management
- Role-group setup command
- Production-oriented security headers/settings
- English + বাংলা authentication UI

Initial setup:
1. Install dependencies.
2. Run migrations.
3. Create a superuser.
4. Run `python manage.py setup_roles`.
5. Log in at `/login/`.
6. Use Django Admin to create users and assign profiles/permissions.

Production note:
This release establishes the application-level security foundation. HTTPS, secure cookies, database backups, server firewalling, secrets management and deployment hardening are still required before public internet deployment.
