# v0.7 — Donation, Zakat & Restricted Fund Management

Added:
- Fund beneficiary records
- Fund distribution records
- Separate received/distributed/available balance per fund
- Zakat/Sadaqah/Dan/Fitrah/Lillah/Waqf fund separation
- Distribution validation against available balance
- Beneficiary and approval tracking
- Professional fund dashboard
- Bilingual fund management UI
- India INR presentation

Note:
This software records fund restrictions and workflows. Religious eligibility rules and final Zakat distribution decisions must be governed by the madrasah's qualified scholar/authorized committee.
