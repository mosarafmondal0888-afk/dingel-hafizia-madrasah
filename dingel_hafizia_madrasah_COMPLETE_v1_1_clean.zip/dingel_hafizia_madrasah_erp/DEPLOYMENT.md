# Deployment Checklist — India + বাংলা Madrasah ERP

## Local setup

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# Linux/macOS: source .venv/bin/activate
pip install -r requirements.txt
python manage.py migrate
python manage.py createsuperuser
python manage.py seed_india
python manage.py setup_roles
python manage.py check
python manage.py test
python manage.py runserver
```

Open `/login/`.

## Backup

```bash
python manage.py backup_database --output backups
```

Keep backups outside the application directory in production.

## Restore

```bash
python manage.py restore_database backups/your-backup.json
```

Always test a restore on a separate database before using it on the live system.

## Production

- Set a strong `DJANGO_SECRET_KEY`.
- Set `DJANGO_DEBUG=False`.
- Configure `DJANGO_ALLOWED_HOSTS`.
- Use HTTPS.
- Use PostgreSQL for multi-user production deployments.
- Store media files separately and back them up.
- Restrict Django Admin to trusted staff.
- Review role permissions before giving financial access.
- Schedule encrypted database backups.
- Do not store full Aadhaar numbers unless the institution has a lawful and documented requirement.
