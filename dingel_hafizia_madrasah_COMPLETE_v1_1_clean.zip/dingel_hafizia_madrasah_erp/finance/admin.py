from django.contrib import admin

from .models import (
    Account,
    Donation,
    DonationFund,
    Expense,
    FeeInvoice,
    FeeInvoiceItem,
    FeeStructure,
    FundBeneficiary,
    FundDistribution,
    ExpenseCategory,
    StaffMember,
    SalaryPayment,
    CashBankTransaction,
    Income,
    FeePayment,
    FeeType,
    LedgerEntry,
)


@admin.register(DonationFund)
class DonationFundAdmin(admin.ModelAdmin):
    list_display = ("code", "name", "is_restricted", "is_active")
    list_filter = ("is_restricted", "is_active")
    search_fields = ("code", "name")


@admin.register(Account)
class AccountAdmin(admin.ModelAdmin):
    list_display = ("code", "name", "account_type", "is_active")
    list_filter = ("account_type", "is_active")
    search_fields = ("code", "name")


@admin.register(FeeType)
class FeeTypeAdmin(admin.ModelAdmin):
    list_display = ("name", "monthly", "is_active")
    list_filter = ("monthly", "is_active")
    search_fields = ("name",)


@admin.register(FeeStructure)
class FeeStructureAdmin(admin.ModelAdmin):
    list_display = ("name", "class_group", "amount", "is_monthly", "is_active")
    list_filter = ("is_monthly", "is_active", "class_group")
    search_fields = ("name",)


@admin.register(FeeInvoiceItem)
class FeeInvoiceItemAdmin(admin.ModelAdmin):
    list_display = ("invoice", "fee_type", "quantity", "unit_amount", "line_total")
    search_fields = ("invoice__invoice_no", "fee_type__name")


@admin.register(FeeInvoice)
class FeeInvoiceAdmin(admin.ModelAdmin):
    list_display = (
        "invoice_no",
        "student",
        "invoice_date",
        "total_amount",
        "paid_amount",
        "due_amount",
    )
    search_fields = ("invoice_no", "student__full_name", "student__admission_no")
    list_filter = ("invoice_date",)


@admin.register(FeePayment)
class FeePaymentAdmin(admin.ModelAdmin):
    list_display = (
        "receipt_no",
        "student",
        "payment_date",
        "amount",
        "method",
    )
    search_fields = ("receipt_no", "student__full_name", "student__admission_no")
    list_filter = ("payment_date", "method")


@admin.register(Donation)
class DonationAdmin(admin.ModelAdmin):
    list_display = (
        "receipt_no",
        "donor_name",
        "fund",
        "donation_date",
        "amount",
        "method",
    )
    search_fields = ("receipt_no", "donor_name", "donor_phone")
    list_filter = ("fund", "donation_date", "method")


@admin.register(Income)
class IncomeAdmin(admin.ModelAdmin):
    list_display = ("receipt_no", "income_date", "income_head", "amount", "method")
    search_fields = ("receipt_no", "income_head")
    list_filter = ("income_date", "method")


@admin.register(Expense)
class ExpenseAdmin(admin.ModelAdmin):
    list_display = (
        "voucher_no",
        "expense_date",
        "expense_head",
        "amount",
        "method",
        "approved_by",
    )
    search_fields = ("voucher_no", "expense_head")
    list_filter = ("expense_date", "method")


@admin.register(LedgerEntry)
class LedgerEntryAdmin(admin.ModelAdmin):
    list_display = (
        "entry_date",
        "account",
        "entry_type",
        "amount",
        "reference",
    )
    search_fields = ("reference", "account__name", "account__code")
    list_filter = ("entry_date", "entry_type", "account")


@admin.register(FundBeneficiary)
class FundBeneficiaryAdmin(admin.ModelAdmin):
    list_display = ("name", "category", "phone", "is_active")
    list_filter = ("category", "is_active")
    search_fields = ("name", "phone")


@admin.register(FundDistribution)
class FundDistributionAdmin(admin.ModelAdmin):
    list_display = (
        "distribution_no",
        "fund",
        "beneficiary",
        "distribution_date",
        "amount",
        "payment_method",
        "approved_by",
    )
    list_filter = ("fund", "distribution_date", "payment_method")
    search_fields = (
        "distribution_no",
        "beneficiary__name",
        "purpose",
    )


@admin.register(ExpenseCategory)
class ExpenseCategoryAdmin(admin.ModelAdmin):
    list_display = ("name", "name_bn", "is_active")
    list_filter = ("is_active",)
    search_fields = ("name", "name_bn")


@admin.register(StaffMember)
class StaffMemberAdmin(admin.ModelAdmin):
    list_display = (
        "employee_id",
        "name",
        "staff_type",
        "phone",
        "monthly_salary",
        "is_active",
    )
    list_filter = ("staff_type", "is_active")
    search_fields = ("employee_id", "name", "name_bn", "phone")


@admin.register(SalaryPayment)
class SalaryPaymentAdmin(admin.ModelAdmin):
    list_display = (
        "salary_no",
        "staff",
        "salary_month",
        "net_amount",
        "payment_method",
        "status",
    )
    list_filter = ("salary_month", "payment_method", "status")
    search_fields = ("salary_no", "staff__name", "staff__employee_id")


@admin.register(CashBankTransaction)
class CashBankTransactionAdmin(admin.ModelAdmin):
    list_display = (
        "transaction_no",
        "transaction_date",
        "account_type",
        "transaction_type",
        "amount",
        "reference",
    )
    list_filter = ("account_type", "transaction_type", "transaction_date")
    search_fields = ("transaction_no", "reference", "description")
