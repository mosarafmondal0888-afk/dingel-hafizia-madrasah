from django.urls import path

from .views import (
    create_monthly_invoice,
    fee_receipt_pdf,
    fund_dashboard,
    record_fund_distribution,
    finance_operations,
    finance_summary,
    record_fee_payment,
)

urlpatterns = [
    path("", finance_summary, name="finance-summary"),
    path("invoice/monthly/", create_monthly_invoice, name="create-monthly-invoice"),
    path("payment/", record_fee_payment, name="record-fee-payment"),
    path("receipt/<int:pk>/", fee_receipt_pdf, name="fee-receipt"),
    path("funds/", fund_dashboard, name="fund-dashboard"),
    path("funds/distribute/", record_fund_distribution, name="fund-distribution"),
    path("operations/", finance_operations, name="finance-operations"),
]
