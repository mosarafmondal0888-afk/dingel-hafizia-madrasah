from decimal import Decimal
from datetime import date

from django.contrib import messages
from django.db import transaction
from django.db.models import Sum
from django.http import HttpResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.utils.dateparse import parse_date

from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas

from .models import (
    CashBankTransaction,
    Donation,
    Expense,
    FeeInvoice,
    FeeInvoiceItem,
    FeePayment,
    SalaryPayment,
    FeeStructure,
    FeeType,
    Income,
)


def finance_summary(request):
    context = {
        "fees": FeePayment.objects.aggregate(total=Sum("amount"))["total"] or 0,
        "donations": Donation.objects.aggregate(total=Sum("amount"))["total"] or 0,
        "income": Income.objects.aggregate(total=Sum("amount"))["total"] or 0,
        "expenses": Expense.objects.aggregate(total=Sum("amount"))["total"] or 0,
        "outstanding": sum(
            invoice.due_amount
            for invoice in FeeInvoice.objects.all()
        ),
        "invoice_count": FeeInvoice.objects.count(),
        "salary_total": SalaryPayment.objects.filter(status=SalaryPayment.Status.PAID).aggregate(total=Sum("net_amount"))["total"] or Decimal("0.00"),
        "cash_deposits": CashBankTransaction.objects.filter(account_type=CashBankTransaction.AccountType.CASH, transaction_type=CashBankTransaction.TransactionType.DEPOSIT).aggregate(total=Sum("amount"))["total"] or Decimal("0.00"),
        "cash_withdrawals": CashBankTransaction.objects.filter(account_type=CashBankTransaction.AccountType.CASH, transaction_type=CashBankTransaction.TransactionType.WITHDRAWAL).aggregate(total=Sum("amount"))["total"] or Decimal("0.00"),
    }
    return render(request, "finance/summary.html", context)


@transaction.atomic
def create_monthly_invoice(request):
    if request.method != "POST":
        return redirect("finance-summary")

    student_id = request.POST.get("student_id")
    fee_month = parse_date(request.POST.get("fee_month", ""))
    academic_year = request.POST.get("academic_year", "").strip()
    if not student_id or not fee_month:
        messages.error(request, "Student and fee month are required.")
        return redirect("finance-summary")

    from students.models import Student

    student = get_object_or_404(Student, pk=student_id)
    structures = FeeStructure.objects.filter(
        is_active=True,
    ).filter(
        class_group__isnull=True
    ) | FeeStructure.objects.filter(
        is_active=True,
        class_group=student.class_group,
    )
    structures = structures.distinct()

    if not structures.exists():
        messages.error(request, "No active fee structure found for this student.")
        return redirect("finance-summary")

    invoice_no = f"INV-{date.today():%Y%m%d}-{student.pk}-{fee_month:%Y%m}"
    invoice, created = FeeInvoice.objects.get_or_create(
        invoice_no=invoice_no,
        defaults={
            "student": student,
            "invoice_date": date.today(),
            "due_date": fee_month,
            "academic_year": academic_year,
            "fee_month": fee_month,
            "description": f"Monthly fees for {fee_month:%B %Y}",
            "total_amount": Decimal("0.00"),
        },
    )
    if not created:
        messages.info(request, f"Invoice {invoice.invoice_no} already exists.")
        return redirect("finance-summary")

    total = Decimal("0.00")
    for structure in structures:
        fee_type, _ = FeeType.objects.get_or_create(name=structure.name)
        item = FeeInvoiceItem.objects.create(
            invoice=invoice,
            fee_type=fee_type,
            description=structure.name,
            quantity=Decimal("1.00"),
            unit_amount=structure.amount,
        )
        total += item.line_total

    invoice.total_amount = total
    invoice.status = FeeInvoice.Status.UNPAID
    invoice.save(update_fields=["total_amount", "status"])

    messages.success(request, f"Invoice {invoice.invoice_no} created.")
    return redirect("finance-summary")


@transaction.atomic
def record_fee_payment(request):
    if request.method != "POST":
        return redirect("finance-summary")

    invoice = get_object_or_404(FeeInvoice, pk=request.POST.get("invoice_id"))
    amount = Decimal(request.POST.get("amount", "0"))
    method = request.POST.get("method", FeePayment.Method.CASH)
    payment_date = parse_date(request.POST.get("payment_date", "")) or date.today()

    if amount <= 0 or amount > invoice.due_amount:
        messages.error(request, "Payment must be greater than zero and not exceed the due amount.")
        return redirect("finance-summary")

    receipt_no = f"FEE-{date.today():%Y%m%d}-{invoice.pk}-{invoice.payments.count()+1}"
    payment = FeePayment.objects.create(
        receipt_no=receipt_no,
        student=invoice.student,
        invoice=invoice,
        payment_date=payment_date,
        amount=amount,
        method=method,
        notes=request.POST.get("notes", "").strip(),
    )
    invoice.paid_amount += amount
    invoice.status = (
        FeeInvoice.Status.PAID
        if invoice.paid_amount >= invoice.total_amount
        else FeeInvoice.Status.PARTIAL
    )
    invoice.save(update_fields=["paid_amount", "status"])

    messages.success(request, f"Payment recorded: {payment.receipt_no}")
    return redirect("fee-receipt", pk=payment.pk)


def fee_receipt_pdf(request, pk):
    payment = get_object_or_404(
        FeePayment.objects.select_related("student", "invoice"),
        pk=pk,
    )
    response = HttpResponse(content_type="application/pdf")
    response["Content-Disposition"] = (
        f'inline; filename="fee-receipt-{payment.receipt_no}.pdf"'
    )
    pdf = canvas.Canvas(response, pagesize=A4)
    width, height = A4

    pdf.setTitle(f"Fee Receipt {payment.receipt_no}")
    pdf.setFont("Helvetica-Bold", 18)
    pdf.drawCentredString(width / 2, height - 60, "Dingel Hafizia Madrasah")
    pdf.setFont("Helvetica", 10)
    pdf.drawCentredString(width / 2, height - 78, "Fee Payment Receipt | India | INR")
    pdf.line(45, height - 90, width - 45, height - 90)

    y = height - 125
    rows = [
        ("Receipt No.", payment.receipt_no),
        ("Invoice No.", payment.invoice.invoice_no if payment.invoice else "-"),
        ("Date", str(payment.payment_date)),
        ("Student", payment.student.full_name),
        ("Admission No.", payment.student.admission_no),
        ("Class / Hifz", payment.student.class_group.name),
        ("Payment Method", payment.get_method_display()),
        ("Amount", f"INR {payment.amount}"),
        ("Invoice Due After Payment", f"INR {payment.invoice.due_amount if payment.invoice else 0}"),
    ]
    pdf.setFont("Helvetica", 11)
    for label, value in rows:
        pdf.drawString(60, y, label)
        pdf.drawString(220, y, value)
        y -= 24

    pdf.line(45, y - 5, width - 45, y - 5)
    pdf.setFont("Helvetica-Bold", 13)
    pdf.drawRightString(width - 60, y - 35, f"TOTAL: INR {payment.amount}")
    pdf.setFont("Helvetica", 9)
    pdf.drawString(60, 55, "Generated by Dingel Hafizia Madrasah ERP")
    pdf.save()
    return response


def fund_dashboard(request):
    from .models import DonationFund, FundDistribution

    funds = []
    for fund in DonationFund.objects.filter(is_active=True):
        received = fund.donations.aggregate(total=Sum("amount"))["total"] or Decimal("0.00")
        distributed = fund.distributions.aggregate(total=Sum("amount"))["total"] or Decimal("0.00")
        funds.append({
            "fund": fund,
            "received": received,
            "distributed": distributed,
            "balance": received - distributed,
        })
    return render(request, "finance/funds.html", {"funds": funds})


@transaction.atomic
def record_fund_distribution(request):
    from .models import DonationFund, FundBeneficiary, FundDistribution

    if request.method != "POST":
        return redirect("fund-dashboard")

    fund = get_object_or_404(DonationFund, pk=request.POST.get("fund_id"))
    beneficiary = get_object_or_404(
        FundBeneficiary,
        pk=request.POST.get("beneficiary_id"),
    )
    amount = Decimal(request.POST.get("amount", "0"))
    distribution_date = parse_date(
        request.POST.get("distribution_date", "")
    ) or date.today()

    received = fund.donations.aggregate(total=Sum("amount"))["total"] or Decimal("0.00")
    distributed = fund.distributions.aggregate(total=Sum("amount"))["total"] or Decimal("0.00")
    balance = received - distributed

    if amount <= 0:
        messages.error(request, "Distribution amount must be greater than zero.")
        return redirect("fund-dashboard")

    if amount > balance:
        messages.error(
            request,
            f"Insufficient available balance in {fund.name}.",
        )
        return redirect("fund-dashboard")

    distribution = FundDistribution.objects.create(
        distribution_no=(
            f"FD-{date.today():%Y%m%d}-{fund.pk}-"
            f"{fund.distributions.count()+1}"
        ),
        fund=fund,
        beneficiary=beneficiary,
        distribution_date=distribution_date,
        amount=amount,
        purpose=request.POST.get("purpose", "").strip(),
        payment_method=request.POST.get(
            "payment_method",
            "CASH",
        ),
        approved_by=request.POST.get("approved_by", "").strip(),
        notes=request.POST.get("notes", "").strip(),
    )
    messages.success(
        request,
        f"Distribution {distribution.distribution_no} recorded.",
    )
    return redirect("fund-dashboard")


def finance_operations(request):
    from .models import CashBankTransaction, ExpenseCategory, StaffMember, SalaryPayment

    context = {
        "categories": ExpenseCategory.objects.filter(is_active=True),
        "staff": StaffMember.objects.filter(is_active=True),
        "salary_total": SalaryPayment.objects.filter(
            status=SalaryPayment.Status.PAID
        ).aggregate(total=Sum("net_amount"))["total"] or Decimal("0.00"),
        "cash_deposits": CashBankTransaction.objects.filter(
            account_type=CashBankTransaction.AccountType.CASH,
            transaction_type=CashBankTransaction.TransactionType.DEPOSIT,
        ).aggregate(total=Sum("amount"))["total"] or Decimal("0.00"),
        "cash_withdrawals": CashBankTransaction.objects.filter(
            account_type=CashBankTransaction.AccountType.CASH,
            transaction_type=CashBankTransaction.TransactionType.WITHDRAWAL,
        ).aggregate(total=Sum("amount"))["total"] or Decimal("0.00"),
    }
    return render(request, "finance/operations.html", context)
