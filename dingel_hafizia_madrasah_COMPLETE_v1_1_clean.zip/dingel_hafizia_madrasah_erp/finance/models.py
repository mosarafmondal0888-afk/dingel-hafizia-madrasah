from decimal import Decimal

from django.core.validators import MinValueValidator
from django.db import models

from students.models import Student


class DonationFund(models.Model):
    code = models.CharField(max_length=30, unique=True)
    name = models.CharField(max_length=120)
    description = models.TextField(blank=True)
    is_restricted = models.BooleanField(default=True)
    is_active = models.BooleanField(default=True)

    def __str__(self):
        return f"{self.code} - {self.name}"


class Account(models.Model):
    class AccountType(models.TextChoices):
        ASSET = "ASSET", "Asset"
        LIABILITY = "LIABILITY", "Liability"
        EQUITY = "EQUITY", "Equity"
        INCOME = "INCOME", "Income"
        EXPENSE = "EXPENSE", "Expense"

    code = models.CharField(max_length=30, unique=True)
    name = models.CharField(max_length=150)
    account_type = models.CharField(max_length=20, choices=AccountType.choices)
    is_active = models.BooleanField(default=True)

    def __str__(self):
        return f"{self.code} - {self.name}"


class FeeType(models.Model):
    name = models.CharField(max_length=120, unique=True)
    monthly = models.BooleanField(default=False)
    is_active = models.BooleanField(default=True)

    def __str__(self):
        return self.name


class FeeStructure(models.Model):
    name = models.CharField(max_length=120)
    amount = models.DecimalField(
        max_digits=12,
        decimal_places=2,
        validators=[MinValueValidator(Decimal("0.00"))],
    )
    class_group = models.ForeignKey(
        "students.ClassGroup",
        on_delete=models.PROTECT,
        null=True,
        blank=True,
        related_name="fee_structures",
    )
    is_monthly = models.BooleanField(default=True)
    is_active = models.BooleanField(default=True)

    class Meta:
        ordering = ["name"]

    def __str__(self):
        return self.name


class FeeInvoiceItem(models.Model):
    invoice = models.ForeignKey(
        "FeeInvoice",
        on_delete=models.CASCADE,
        related_name="items",
    )
    fee_type = models.ForeignKey(
        FeeType,
        on_delete=models.PROTECT,
        related_name="invoice_items",
    )
    description = models.CharField(max_length=255, blank=True)
    quantity = models.DecimalField(
        max_digits=8,
        decimal_places=2,
        default=Decimal("1.00"),
        validators=[MinValueValidator(Decimal("0.01"))],
    )
    unit_amount = models.DecimalField(
        max_digits=12,
        decimal_places=2,
        validators=[MinValueValidator(Decimal("0.00"))],
    )

    @property
    def line_total(self):
        return self.quantity * self.unit_amount


class FeeInvoice(models.Model):
    class Status(models.TextChoices):
        UNPAID = "UNPAID", "Unpaid"
        PARTIAL = "PARTIAL", "Partially Paid"
        PAID = "PAID", "Paid"

    student = models.ForeignKey(
        Student,
        on_delete=models.PROTECT,
        related_name="fee_invoices",
    )
    invoice_no = models.CharField(max_length=40, unique=True)
    invoice_date = models.DateField()
    due_date = models.DateField(null=True, blank=True)
    description = models.CharField(max_length=255, blank=True)
    academic_year = models.CharField(max_length=20, blank=True)
    fee_month = models.DateField(null=True, blank=True)
    total_amount = models.DecimalField(
        max_digits=12,
        decimal_places=2,
        validators=[MinValueValidator(Decimal("0.00"))],
    )
    status = models.CharField(max_length=10, choices=Status.choices, default=Status.UNPAID)
    paid_amount = models.DecimalField(
        max_digits=12,
        decimal_places=2,
        default=Decimal("0.00"),
        validators=[MinValueValidator(Decimal("0.00"))],
    )

    @property
    def due_amount(self):
        return max(self.total_amount - self.paid_amount, Decimal("0.00"))

    def __str__(self):
        return self.invoice_no


class FeePayment(models.Model):
    class Method(models.TextChoices):
        CASH = "CASH", "Cash"
        BANK = "BANK", "Bank"
        MOBILE = "MOBILE", "Mobile Banking"
        UPI = "UPI", "UPI"
        CHEQUE = "CHEQUE", "Cheque"

    receipt_no = models.CharField(max_length=40, unique=True)
    student = models.ForeignKey(
        Student,
        on_delete=models.PROTECT,
        related_name="fee_payments",
    )
    invoice = models.ForeignKey(
        FeeInvoice,
        on_delete=models.PROTECT,
        related_name="payments",
        null=True,
        blank=True,
    )
    payment_date = models.DateField()
    amount = models.DecimalField(
        max_digits=12,
        decimal_places=2,
        validators=[MinValueValidator(Decimal("0.01"))],
    )
    method = models.CharField(max_length=20, choices=Method.choices)
    notes = models.TextField(blank=True)

    def __str__(self):
        return self.receipt_no


class Donation(models.Model):
    class Method(models.TextChoices):
        CASH = "CASH", "Cash"
        BANK = "BANK", "Bank"
        MOBILE = "MOBILE", "Mobile Banking"
        UPI = "UPI", "UPI"
        CHEQUE = "CHEQUE", "Cheque"

    receipt_no = models.CharField(max_length=40, unique=True)
    donor_name = models.CharField(max_length=180, blank=True)
    donor_phone = models.CharField(max_length=30, blank=True)
    fund = models.ForeignKey(
        DonationFund,
        on_delete=models.PROTECT,
        related_name="donations",
    )
    donation_date = models.DateField()
    amount = models.DecimalField(
        max_digits=12,
        decimal_places=2,
        validators=[MinValueValidator(Decimal("0.01"))],
    )
    method = models.CharField(max_length=20, choices=Method.choices)
    purpose = models.CharField(max_length=255, blank=True)
    notes = models.TextField(blank=True)

    def __str__(self):
        return self.receipt_no


class Income(models.Model):
    class Method(models.TextChoices):
        CASH = "CASH", "Cash"
        BANK = "BANK", "Bank"
        MOBILE = "MOBILE", "Mobile Banking"
        UPI = "UPI", "UPI"
        CHEQUE = "CHEQUE", "Cheque"

    receipt_no = models.CharField(max_length=40, unique=True)
    income_date = models.DateField()
    income_head = models.CharField(max_length=120)
    amount = models.DecimalField(
        max_digits=12,
        decimal_places=2,
        validators=[MinValueValidator(Decimal("0.01"))],
    )
    method = models.CharField(max_length=20, choices=Method.choices)
    description = models.TextField(blank=True)

    def __str__(self):
        return self.receipt_no


class Expense(models.Model):
    class Method(models.TextChoices):
        CASH = "CASH", "Cash"
        BANK = "BANK", "Bank"
        MOBILE = "MOBILE", "Mobile Banking"
        UPI = "UPI", "UPI"
        CHEQUE = "CHEQUE", "Cheque"

    voucher_no = models.CharField(max_length=40, unique=True)
    expense_date = models.DateField()
    expense_head = models.CharField(max_length=120)
    amount = models.DecimalField(
        max_digits=12,
        decimal_places=2,
        validators=[MinValueValidator(Decimal("0.01"))],
    )
    method = models.CharField(max_length=20, choices=Method.choices)
    description = models.TextField(blank=True)
    approved_by = models.CharField(max_length=150, blank=True)

    def __str__(self):
        return self.voucher_no


class LedgerEntry(models.Model):
    class EntryType(models.TextChoices):
        DEBIT = "DEBIT", "Debit"
        CREDIT = "CREDIT", "Credit"

    entry_date = models.DateField()
    account = models.ForeignKey(
        Account,
        on_delete=models.PROTECT,
        related_name="ledger_entries",
    )
    entry_type = models.CharField(max_length=10, choices=EntryType.choices)
    amount = models.DecimalField(
        max_digits=12,
        decimal_places=2,
        validators=[MinValueValidator(Decimal("0.01"))],
    )
    reference = models.CharField(max_length=80)
    description = models.TextField(blank=True)

    def __str__(self):
        return f"{self.entry_date} - {self.account}"


class FundBeneficiary(models.Model):
    class Category(models.TextChoices):
        POOR = "POOR", "Poor / Needy"
        STUDENT = "STUDENT", "Student Welfare"
        DEBTOR = "DEBTOR", "Debtor"
        TRAVELLER = "TRAVELLER", "Traveller"
        OTHER = "OTHER", "Other"

    name = models.CharField(max_length=180)
    phone = models.CharField(max_length=30, blank=True)
    category = models.CharField(max_length=20, choices=Category.choices)
    address = models.TextField(blank=True)
    notes = models.TextField(blank=True)
    is_active = models.BooleanField(default=True)

    def __str__(self):
        return self.name


class FundDistribution(models.Model):
    distribution_no = models.CharField(max_length=40, unique=True)
    fund = models.ForeignKey(
        DonationFund,
        on_delete=models.PROTECT,
        related_name="distributions",
    )
    beneficiary = models.ForeignKey(
        FundBeneficiary,
        on_delete=models.PROTECT,
        related_name="distributions",
    )
    distribution_date = models.DateField()
    amount = models.DecimalField(
        max_digits=12,
        decimal_places=2,
        validators=[MinValueValidator(Decimal("0.01"))],
    )
    purpose = models.CharField(max_length=255)
    payment_method = models.CharField(
        max_length=20,
        choices=Donation.Method.choices,
        default=Donation.Method.CASH,
    )
    approved_by = models.CharField(max_length=150, blank=True)
    notes = models.TextField(blank=True)

    def __str__(self):
        return self.distribution_no


class ExpenseCategory(models.Model):
    name = models.CharField(max_length=120, unique=True)
    name_bn = models.CharField(max_length=120, blank=True)
    is_active = models.BooleanField(default=True)

    class Meta:
        ordering = ["name"]

    def __str__(self):
        return self.name


class StaffMember(models.Model):
    class StaffType(models.TextChoices):
        TEACHER = "TEACHER", "Teacher"
        IMAM = "IMAM", "Imam"
        OFFICE = "OFFICE", "Office Staff"
        COOK = "COOK", "Cook"
        SUPPORT = "SUPPORT", "Support Staff"
        OTHER = "OTHER", "Other"

    employee_id = models.CharField(max_length=40, unique=True)
    name = models.CharField(max_length=180)
    name_bn = models.CharField(max_length=180, blank=True)
    staff_type = models.CharField(max_length=20, choices=StaffType.choices)
    phone = models.CharField(max_length=30, blank=True)
    joining_date = models.DateField(null=True, blank=True)
    monthly_salary = models.DecimalField(
        max_digits=12,
        decimal_places=2,
        default=Decimal("0.00"),
        validators=[MinValueValidator(Decimal("0.00"))],
    )
    is_active = models.BooleanField(default=True)

    def __str__(self):
        return f"{self.employee_id} - {self.name}"


class SalaryPayment(models.Model):
    class Status(models.TextChoices):
        PAID = "PAID", "Paid"
        VOID = "VOID", "Void"

    salary_no = models.CharField(max_length=40, unique=True)
    staff = models.ForeignKey(
        StaffMember,
        on_delete=models.PROTECT,
        related_name="salary_payments",
    )
    salary_month = models.DateField()
    gross_amount = models.DecimalField(
        max_digits=12,
        decimal_places=2,
        validators=[MinValueValidator(Decimal("0.01"))],
    )
    deduction = models.DecimalField(
        max_digits=12,
        decimal_places=2,
        default=Decimal("0.00"),
        validators=[MinValueValidator(Decimal("0.00"))],
    )
    net_amount = models.DecimalField(
        max_digits=12,
        decimal_places=2,
        validators=[MinValueValidator(Decimal("0.01"))],
    )
    payment_method = models.CharField(
        max_length=20,
        choices=Donation.Method.choices,
        default=Donation.Method.BANK,
    )
    payment_date = models.DateField()
    status = models.CharField(
        max_length=10,
        choices=Status.choices,
        default=Status.PAID,
    )
    notes = models.TextField(blank=True)

    def __str__(self):
        return self.salary_no


class CashBankTransaction(models.Model):
    class TransactionType(models.TextChoices):
        DEPOSIT = "DEPOSIT", "Deposit"
        WITHDRAWAL = "WITHDRAWAL", "Withdrawal"
        TRANSFER = "TRANSFER", "Transfer"

    class AccountType(models.TextChoices):
        CASH = "CASH", "Cash"
        BANK = "BANK", "Bank"
        UPI = "UPI", "UPI"

    transaction_no = models.CharField(max_length=40, unique=True)
    transaction_date = models.DateField()
    account_type = models.CharField(max_length=10, choices=AccountType.choices)
    transaction_type = models.CharField(max_length=15, choices=TransactionType.choices)
    amount = models.DecimalField(
        max_digits=12,
        decimal_places=2,
        validators=[MinValueValidator(Decimal("0.01"))],
    )
    reference = models.CharField(max_length=120, blank=True)
    description = models.TextField(blank=True)
    approved_by = models.CharField(max_length=150, blank=True)

    def __str__(self):
        return self.transaction_no
