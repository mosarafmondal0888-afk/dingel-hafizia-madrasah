# Dingel Hafizia Madrasah ERP

Professional starter ERP for a Hafizia/Dingel Madrasah.

## Included in v0.1

- Secure Django admin
- Dashboard
- Student profiles
- Hifz/Quran progress
- Fee invoices and payments
- Donation/fund management
- Income and expense transactions
- Cash/bank accounts
- Double-entry-ready ledger structure
- Role-ready user model
- REST API foundation
- English/Bangla-ready labels
- SQLite development database
- PostgreSQL-ready configuration
- Seed command for demo data

## Quick start

Python 3.11+ is recommended.

```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# Linux/macOS:
source .venv/bin/activate

pip install -r requirements.txt
python manage.py migrate
python manage.py seed_demo
python manage.py createsuperuser
python manage.py runserver
```

Open:
- Dashboard: http://127.0.0.1:8000/
- Admin: http://127.0.0.1:8000/admin/

## PostgreSQL

Set these environment variables before running:

```text
DB_ENGINE=postgresql
DB_NAME=madrasah
DB_USER=postgres
DB_PASSWORD=your_password
DB_HOST=127.0.0.1
DB_PORT=5432
```

Then run:

```bash
python manage.py migrate
```


## India + বাংলা

This version is configured for India:
- INR (₹)
- Asia/Kolkata
- April–March financial year
- English + বাংলা UI
- Indian states/UT master data


## v1.1 Production Hardening

- Backup/restore management commands
- Authentication smoke tests
- Deployment checklist
- Environment configuration template
- Production security settings helper
