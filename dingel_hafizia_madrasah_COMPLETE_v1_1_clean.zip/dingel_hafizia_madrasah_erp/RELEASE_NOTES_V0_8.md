# v0.8 — Expenses, Payroll & Cash/Bank

Added:
- Expense categories
- Staff/teacher master
- Salary payments
- Salary deductions and net pay
- Cash/bank/UPI transaction register
- Deposit / withdrawal / transfer transaction types
- Operations dashboard
- Payroll shortcuts
- Cash/bank controls
- English + বাংলা labels

Next:
- Financial reports
- Monthly/yearly profit & fund reports
- Cash book
- Bank reconciliation
- Excel/PDF export
- Role permissions and audit log
